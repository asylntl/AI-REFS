"""Map an edited video (cuts / slow-mo) back to the original generation, frame by frame.
python3 match_edit.py EDIT.mov GENERATION.mp4 OUT_DIR "48,216,336,408" ["48,176,249,321"]
  5th arg (optional) = cuts of the edit, if auto-detection is wrong.
  4th arg = shot boundaries (frames) of the generation (= the previz cut frames, since gen frame n = previz frame n).
Writes OUT_DIR/timemap.json: {"t": [fractional previz frame for every edit frame], "black": [edit frames that are black]}
Method: 64x36 grayscale, luma-normalised correlation (robust to colour grade; plain MSE breaks on graded static shots),
monotonic DP per shot with a prior for step=1, sub-frame refinement + smoothing on slowed parts."""
import sys, os, subprocess, json, numpy as np
E, G, D, CUTS = sys.argv[1], sys.argv[2], sys.argv[3], [int(x) for x in sys.argv[4].split(',')]
os.makedirs(D, exist_ok=True)
def grab(p, out):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', p, '-vf', 'scale=64:36,format=gray', '-f', 'rawvideo', out], check=True)
    return np.fromfile(out, np.uint8).reshape(-1, 36, 64).astype(float)
F = grab(E, D + '/_e.raw'); R = grab(G, D + '/_g.raw')
def nz(x): x = x.reshape(len(x), -1); x = x - x.mean(1, keepdims=True); return x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-6)
fn, rn = nz(F), nz(R)
# edit cuts: frames with content on both sides, change persists for +-2 frames (ignores black, flashes, a bat crossing)
std = F.reshape(len(F), -1).std(1)
def c(i, j): return fn[i] @ fn[j]
ecuts = []
if len(sys.argv) > 5: ecuts = [int(x) for x in sys.argv[5].split(',')]          # optional: edit cuts by hand
else:
    for i in range(2, len(F) - 2):
        if min(std[i - 2:i + 2]) < 4: continue
        if c(i - 1, i) < 0.6 and c(i - 2, i + 1) < 0.6 and c(i - 1, i + 2) < 0.6 and c(i, i + 1) > 0.8:
            if not ecuts or i - ecuts[-1] > 3: ecuts.append(i)
    if len(ecuts) > len(CUTS):                    # keep the strongest changes (a passing bird/bat is weaker than a cut)
        ecuts = sorted(sorted(ecuts, key=lambda i: c(i - 2, i + 1) + c(i - 1, i))[:len(CUTS)])
print('edit cuts (frames):', ecuts)
fc = [0] + ecuts + [len(F)]; rc = [0] + CUTS + [len(R)]
assert len(fc) == len(rc), f'edit has {len(fc)-1} shots, generation {len(rc)-1}: pass matching cuts'
def dp(M, lam=0.01):
    n, m = M.shape; Dd = np.full((n, m), 1e18); P = np.zeros((n, m), int); Dd[0] = M[0]
    for i in range(1, n):
        for j in range(m):
            ks = np.arange(max(0, j - 3), j + 1); c = Dd[i - 1][ks] + lam * np.abs((j - ks) - 1)
            b = c.argmin(); Dd[i, j] = c[b] + M[i, j]; P[i, j] = ks[b]
    j = int(Dd[-1].argmin()); p = [j]
    for i in range(n - 1, 0, -1): j = P[i][j]; p.append(j)
    return p[::-1]
t = []
for k in range(len(fc) - 1):
    a, b, ra, rb = fc[k], fc[k + 1], rc[k], rc[k + 1]
    p = dp(1 - fn[a:b] @ rn[ra:rb].T); seg = np.array([ra + x for x in p], float)
    for i in range(len(seg)):                       # sub-frame refinement
        j = int(seg[i])
        if 1 <= j < len(R) - 1:
            c = [fn[a + i] @ rn[j - 1], fn[a + i] @ rn[j], fn[a + i] @ rn[j + 1]]; den = c[0] - 2 * c[1] + c[2]
            if den < 0 and (np.diff(seg) == 0).any(): seg[i] = j + np.clip(0.5 * (c[0] - c[2]) / den, -.5, .5)
    if (np.diff(np.array(p)) == 0).any():           # slowed part: smooth
        k7 = 7; sm = np.convolve(np.pad(seg, (3, 3), mode='edge'), np.ones(k7) / k7, mode='valid'); seg = np.maximum.accumulate(sm)
    t += list(seg); sp = np.diff(seg)
    print(f'shot {k}: edit {a}-{b-1} -> gen {seg[0]:.1f}-{seg[-1]:.1f}, speed by second:', [round(float(sp[x:x+24].mean()), 2) for x in range(0, len(sp), 24)])
black = [i for i in range(len(F)) if F[i].mean() < 3]
json.dump({'t': [float(x) for x in t], 'black': black}, open(D + '/timemap.json', 'w')); print('timemap.json written,', len(t), 'frames')
