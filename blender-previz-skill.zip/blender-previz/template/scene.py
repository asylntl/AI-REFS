"""TEMPLATE previz: 3 shots, 10 s (240 f), 16:9.
 Shot 1 (0-72)   static wide: hero walks in from the left and stops in front of a landmark.
 Shot 2 (72-168) slow orbit around his head, 35 mm -> 28 mm, ends behind his right shoulder.
 Shot 3 (168-240) far handheld from behind, he crouches on the roof edge, city below.
Run ($BLENDER = path to Blender, see tools/find_blender.sh):
  "$BLENDER" -b --factory-startup -P scene.py -- stills 20,100,200 out ./previz_out   # check frames
  "$BLENDER" -b --factory-startup -P scene.py -- render out ./previz_out              # full video
Copy this file into <project>/scripts/, then change the PROJECT block.
If you copy it elsewhere, set SKILL_DIR (env var) to the skill folder so the lib is found.
"""
import sys, os, math
SKILL_DIR = os.environ.get('SKILL_DIR') or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(SKILL_DIR, 'lib'))
from previz_lib import *

# ---------- PROJECT ----------
NAME = 'template'
sc = setup(w=1920, h=1080, frames=240)
OUT_DIR = out_dir()                                # -- out DIR, default ./previz_out

# ---------- look ----------
sky(); sun()
ground()
M_STONE = mat('stone', (0.86, 0.82, 0.74)); M_BLD = fog_mat('bld', (0.70, 0.70, 0.71))
M_BODY = mat('body', (0.16, 0.17, 0.2)); M_HEAD = mat('head', (0.75, 0.72, 0.68)); M_EYE = mat('eye', (0.02, 0.02, 0.02))
M_CAPE = mat('cape', (0.02, 0.02, 0.025), 0.8); M_TXT = mat('gold', (0.85, 0.64, 0.25), 0.35)

# ---------- set: landmark block with inscription + roof + far city ----------
box('LANDMARK', (20, 8, 16), (0, 10, 8), M_STONE)
text3d('INSCRIPTION', 'LANDMARK', (0, 5.95, 12), 1.4, M_TXT)          # facade faces -Y -> rot (90,0,0)
import random; random.seed(3)
for i in range(40):
    x = random.uniform(-300, 300); y = random.uniform(60, 600); hgt = random.uniform(15, 45)
    box('CITY', (random.uniform(15, 35), random.uniform(15, 35), hgt), (x, y, hgt / 2), M_BLD)

# ---------- hero ----------
H = build_hero('HERO', M_BODY, M_HEAD, M_EYE, M_CAPE, 1.2)
STOP = Vector((0, -6, 0)); START = STOP + Vector((-4, 0, 0))
walk(H, 0, 40, START, STOP)
for f in (42, 168): kroot(H, f, STOP, face_q((0, 1, 0)))               # turns to the landmark
khead(H, 0, 0, -5); khead(H, 50, 0, -25); khead(H, 168, 0, -25)
for s in 'LR': karm(H, s, 0); karm(H, s, 168)
kpelvis(H, 0); kcape(H, 0, 0)
# HOLD keys right before the cut, otherwise the pose blends from 0 to 169 for the whole shot 2
kpelvis(H, 168); kcape(H, 168, 0); kleg(H, 'L', 41, 0); kleg(H, 'R', 41, 0); kleg(H, 'L', 168, 0); kleg(H, 'R', 168, 0)
ROOF = Vector((0, 10 - 3.5, 16))                                         # on the landmark roof, facing -Y (to the city? swap as needed)
kroot(H, 169, ROOF, face_q((0, -1, 0))); kroot(H, 239, ROOF, face_q((0, -1, 0)))
crouch(H, 169); crouch(H, 239); kcape(H, 169, -62); khead(H, 169, 0, -30)
for s in 'LR': karm(H, s, 169, -70)

# ---------- cameras ----------
C1 = cam('CAM_1', 35)
P1 = STOP + Vector((0.6, -7, 1.2)); T1 = (STOP + UP * 1.4).lerp(Vector((0, 5.9, 12)), 0.35)   # hero low in frame, inscription on top
ckey(C1, 0, P1, T1, 28); ckey(C1, 71, P1, T1, 28)

A2 = hero_axes(H, 100)
C2 = cam('CAM_2', 35)
for f in range(72, 168):
    u = ease((f - 72) / 96)
    pos = orbit_pos(A2['HEAD'], A2['FWD'], A2['RIGHT'], math.radians(30 + 150 * u), 1.6 - 0.9 * u, -0.3 * (1 - u) + 0.1 * u)
    tgt = (A2['HEAD'] + UP * 0.05).lerp(A2['HEAD'] + A2['FWD'] * 8 + UP * 3, ease((f - 130) / 38))   # face first, then over the shoulder to the landmark
    ckey(C2, f, pos, tgt, 35 + (28 - 35) * u)

C3 = cam('CAM_3', 50)
BASE = ROOF + Vector((2.0, 9.0, 2.5))
for f in range(168, 240, 2):
    fl, aj = handheld(f / 24)
    ckey(C3, f, BASE + fl, ROOF + Vector((0, -200, -25)) + aj, 50)

markers([(0, C1), (72, C2), (168, C3)])
finish(linear_cams=(C2,))
save_and_run(f'{OUT_DIR}/{NAME}.blend', f'{OUT_DIR}/renders/_raw_{NAME}_', f'{OUT_DIR}/renders/_{NAME}_')
