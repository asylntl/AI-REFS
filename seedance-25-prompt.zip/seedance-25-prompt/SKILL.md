---
name: "seedance-25-prompt"
description: "Build a Seedance 2.5 video generation prompt in ByteDance's official plain-text block format (creatives description, one-sentence summary, timestamped stages with positive/negative lines, global supplement). Use whenever the user asks for a Seedance prompt, a video generation prompt, wants to turn a scene or idea into a Seedance 2.5 brief, or says things like \"make a prompt for Seedance\", \"write me a video prompt\", \"напиши промпт для сиданс\". Do NOT use for Veo, Runway, Kling, Sora, Pika or Luma unless the user asks to adapt the result for Seedance 2.5."
---

# Seedance 2.5 Prompt Builder (official plain-text format)

Turn a scene description into one Seedance 2.5 prompt written in ByteDance's official block format. **Output is plain text, never JSON.**

## Ask before writing

Unless the user already said so, ask in one short round: duration, character/location reference tags, and whether there is dialogue. Do not ask more than three questions.

## Output structure

Always these four blocks, in this order:

```
[Creatives Description]
[One-sentence summary]
[Specific plot description]   ← stages
[Global supplement]
```

### 1. Creatives Description

One line per reference: the tag, what it is (character / voice / motion / scene), and **what to ignore**.

```
@[TagName](uuid) — character: <who they are in one clause>.
@[LocationTag](uuid) — scene: <what it provides>. Use the space, materials and lighting only, not any people in it.

Based on the uploaded images, strictly maintain the consistency of each character's face and features, and strictly lock <who is where>.
```

`strictly maintain` and `strictly lock` are the official strength words. Use them for identity and for blocking.

Skip this block entirely if there are no references.

### 2. One-sentence summary

`Subject + Location + Event + Theme/Style + Special camera movement` — one sentence, no more.

### 3. Specific plot description

Stages on a timeline. Each stage gets a time range, an emotion label and a short title:

```
Stage 2: 4-8s [Confusion] — The glass
➕ <picture content + camera + action + dialogue + sound effects>
➖ <unwanted elements in this stage>
```

Rules for stages:

- **One main change and one clear end state per stage.** Two events in one stage and the beat gets rushed.
- Timestamps are a **time budget**, not frame-exact edit points. Give each beat air.
- Name the lens in mm inside the ➕ line: 35mm for a group, 50mm for a medium, 85mm for a close-up, 100–135mm for an extreme close-up. Degrees of FOV do not work reliably.
- State the crop explicitly for tight shots: "the face filling the whole frame from forehead to chin, head cropped at the top and bottom of frame". Without it the model leaves shoulders in.
- Mark cuts as `Hard cut at second N to ...`.
- Dialogue: declare language and delivery before the line — `Dialogue language: English, low and controlled, falling tone. <TAG> says: "..."`. Falling tone must be stated or statements come out sounding like questions.
- Every ➖ line should carry at minimum `no subtitles, no background music`.

### 4. Global supplement

Everything that must hold across the whole video, said once:

- environment, grade in Kelvin, lighting, lens character, camera behaviour (handheld / gimbal-smooth)
- what stays constant: faces, hair, clothing, positions, props in hand
- `Strictly lock:` a line with the hardest constraints — number of people, who is where
- `Globally not wanted:` subtitles, on-screen text, background music, plus the project's recurring failures
- sound design in one line

## Writing rules

**Write the visible.** Translate every abstraction into something that can be seen or heard. Emotion goes through muscle movement, never labels: not "she looks sad" but "her eyes drop, her jaw loosens, she swallows once before answering".

**Negatives work in 2.5.** Unlike 2.0, prohibitions are part of the official format — per stage in the ➖ line and globally at the end. Use them.

**Character descriptions.** With a reference tag, keep appearance minimal — long descriptions fight the reference and degrade it. Only when there is **no** reference use the full formula:

```
Character = [Age/Race] + [Skin colour and texture] + [Facial details] + [Eyes/Soul]
          + [Hairstyle/Hair colour] + [Clothing/Fabric texture]
          + [Body type/Emotion/Temperament] + [Other]
```

- Age/Race: `[specific age] + [nationality] + [style adjective] + [face-shape noun]`
- Eyes/Soul: `[eye adjective] + [what the gaze conveys] + [emotion underneath]`
- Hairstyle: describe state, curl and texture, never just a colour
- Body/Temperament: figure + how it is framed + overall impression

**Directions.** State screen direction from the camera, and give distances in meters when two subjects share a frame. If a character looks at someone off frame, either name that person as off frame **or** put a visible target in frame — an eyeline with no anchor drifts.

**One camera move per shot.** Stacked moves degrade. If a move must be smooth, say `gimbal-smooth ... completely steady with no shake at any point`; if handheld, describe the physical sway rather than writing "locked-off".

## Length and limits

- One generation: up to **30 seconds**
- Nested extension: up to **60 seconds** total
- Ultra Long Video mode: up to **180 seconds**
- References: up to 50 files — 30 images, 10 video, 10 audio. Stability drops past **8 distinct subjects**; three character tags in one shot is the practical ceiling before faces start blending.

## Extension and editing

**Extension.** Required vocabulary: `Forward extension`, `Backward extension`, `Continuation`. Lock the boundary frame first — subject pose and orientation, prop position, background, camera position, lighting, motion direction — then describe what happens next. For a transition extension: `cut shot setting = [transition type] + [basic constraints] + [cut logic]`.

**Editing a generated video.** Box-select, arrow or anchor a region, add a prompt, pick the timestamp. Name four things: which video is the master, what changes, how far the change reaches, and what must stay untouched. Editing locks the source aspect ratio and roughly its duration (±0.3s).

## Known failure modes and their fixes

| Symptom | Cause | Fix |
|---|---|---|
| Characters swap roles | two similar tags in one shot, ambiguous pronouns | one tag per generation where possible; never use pronouns, repeat the tag; anchor with posture (one seated, one standing) |
| An extra person appears | someone described as being off frame | say `alone in frame and the only person visible`, or give a visible in-frame target instead |
| Frame is wider than asked | shot size named but crop not described | state where the frame cuts, plus the lens in mm |
| Faces come out wet | many "wet" mentions in the environment | `faces, hair and clothing stay completely dry, the water sitting only on the ground` |
| Hoods, hats, props change | detail stated only in the subject line | repeat it inside the action line too |
| Drops or particles render huge | no scale given | give a physical size: "the size of a pinhead, barely visible" |
| Background lights read as floating orbs | "points of light" with shallow depth of field | "a faint even warm glow spread across it" |
| Dialogue sounds like a question | rising intonation not suppressed | `ending on a full stop with a falling tone` |
| Delivery too hysterical | volume raised without pitch control | `loud enough to carry, pitched low in the chest, controlled rather than strained` |
| Blood appears near an injured character | model default | `no blood` in the stage line and globally; describe an unconscious person as "resting quietly, eyes closed, as if asleep" |
| A person walks in the road | pavement not named | name the pavement, kerb and parked cars as markers |
| Rain renders badly | rain drawn directly | show wet surfaces, puddles, damp hair instead |
| Slow motion looks fake | labelled instead of shown | suspend object physics — droplets hanging, fabric arcing — while the camera keeps moving in real time |
| Subject appears far away when they should be close | distance never stated | give it in meters and repeat in the camera line |
| A subject teleports across a cut | distance changed without motion | have the character physically cover the distance on screen |

## Output

Reply with the prompt as a plain-text block, then a short note listing the shot sizes, lenses and camera angles used, and the reasoning behind the two or three key staging choices. Keep the note brief — no restating of the prompt.

