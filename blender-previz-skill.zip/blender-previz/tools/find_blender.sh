#!/bin/sh
# Prints the Blender executable: $BLENDER if set, else common install locations (macOS / Linux / Windows-Git-Bash).
# Usage:  BLENDER="$(sh tools/find_blender.sh)"
[ -n "$BLENDER" ] && [ -x "$BLENDER" ] && { echo "$BLENDER"; exit 0; }
for p in /Applications/Blender.app/Contents/MacOS/Blender "$HOME/Applications/Blender.app/Contents/MacOS/Blender" \
         "$(command -v blender 2>/dev/null)" /usr/bin/blender /snap/bin/blender /opt/blender/blender \
         "/c/Program Files/Blender Foundation"/Blender*/blender.exe; do
  [ -n "$p" ] && [ -x "$p" ] && { echo "$p"; exit 0; }
done
echo "Blender not found: set BLENDER=/path/to/blender" >&2; exit 1
