﻿Тебе не жарко? Ролик за 4 генерации / Aren’t you hot? A video in 4 generations
Higgsfield + ElevenLabs + Claude · Seedream 5 Pro + ElevenLabs v3 + Blender + Seedance 2.5 · [object Object]
https://akzholai.com/prompt/zharko/

RU
1. Откройте сервис и модель, указанные выше, выберите формат.
2. Загрузите файлы в том порядке, как подписаны теги в промпте (Image 1, Image 2, Video 1).
3. Вставьте промпт из .txt и запустите генерацию.
   У каждой сцены своя папка: свои файлы и свой промпт.

EN
1. Open the platform and model listed above and choose the aspect ratio.
2. Upload the files in the order the prompt tags say (Image 1, Image 2, Video 1).
3. Paste the prompt from the .txt file and generate.
   Each scene has its own folder with its own files and prompt.

@ak.zhol · akzholai.com