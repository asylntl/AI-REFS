"""previz_lib — helpers for simple Seedance previz in Blender 5.x (background mode).
Usage inside a scene script (see template/scene.py):
    import sys, os; sys.path.insert(0, os.path.join(SKILL_DIR, 'lib'))
    from previz_lib import *
    setup(w=1920, h=1080, frames=480)
Everything is plain data API: no UI, no operators except render/save/boolean apply.
"""
import bpy, bmesh, math, sys
from mathutils import Vector, Quaternion, Euler, Matrix

UP = Vector((0, 0, 1))
ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
sc = None
FOG = (0.55, 0.60, 0.68)

# ---------------- scene ----------------
def setup(w=1920, h=1080, frames=480, fps=24):
    """Empty scene, EEVEE light mode (8 samples, no shadows) -> ~0.5 s/frame on a modern laptop."""
    global sc
    bpy.ops.wm.read_factory_settings(use_empty=True)
    sc = bpy.context.scene
    sc.render.resolution_x, sc.render.resolution_y = w, h
    sc.render.fps = fps; sc.frame_start, sc.frame_end = 0, frames - 1
    sc.view_settings.view_transform = 'Standard'
    sc.render.engine = 'BLENDER_EEVEE'; sc.eevee.taa_render_samples = 8
    return sc

def light_mode():
    """Call once at the end: no shadows anywhere (shadows flicker and cost time)."""
    sc.eevee.taa_render_samples = 8
    for l in bpy.data.lights: l.use_shadow = False

def sun(strength=3.0, rot=(50, 0, 30)):
    ld = bpy.data.lights.new('SUN', 'SUN'); ld.energy = strength; ld.use_shadow = False
    o = link(bpy.data.objects.new('SUN', ld)); o.rotation_euler = tuple(math.radians(a) for a in rot); return o

def sky(horizon=FOG, zenith=(0.2, 0.28, 0.42), ambient=(0.5, 0.52, 0.56), amb_strength=0.6):
    """Gradient sky for camera rays + flat ambient for lighting."""
    w = bpy.data.worlds.new('WORLD'); sc.world = w; w.use_nodes = True; wn = w.node_tree
    for n in list(wn.nodes): wn.nodes.remove(n)
    tc = wn.nodes.new('ShaderNodeTexCoord'); sep = wn.nodes.new('ShaderNodeSeparateXYZ'); mr = wn.nodes.new('ShaderNodeMapRange')
    mr.inputs['From Min'].default_value = -0.02; mr.inputs['From Max'].default_value = 0.6; mr.clamp = True
    mx = wn.nodes.new('ShaderNodeMix'); mx.data_type = 'RGBA'
    mx.inputs['A'].default_value = (*horizon, 1); mx.inputs['B'].default_value = (*zenith, 1)
    bc = wn.nodes.new('ShaderNodeBackground'); ba = wn.nodes.new('ShaderNodeBackground')
    ba.inputs[0].default_value = (*ambient, 1); ba.inputs[1].default_value = amb_strength
    lp = wn.nodes.new('ShaderNodeLightPath'); ms = wn.nodes.new('ShaderNodeMixShader'); wo = wn.nodes.new('ShaderNodeOutputWorld')
    L = wn.links.new
    L(tc.outputs['Generated'], sep.inputs[0]); L(sep.outputs['Z'], mr.inputs['Value']); L(mr.outputs[0], mx.inputs['Factor'])
    L(mx.outputs['Result'], bc.inputs[0]); L(lp.outputs['Is Camera Ray'], ms.inputs[0]); L(ba.outputs[0], ms.inputs[1])
    L(bc.outputs[0], ms.inputs[2]); L(ms.outputs[0], wo.inputs[0])

# ---------------- materials ----------------
def _clear(m):
    m.use_nodes = True; nt = m.node_tree
    for n in list(nt.nodes): nt.nodes.remove(n)
    return nt
def mat(name, rgb, rough=0.75):
    m = bpy.data.materials.new(name); m.diffuse_color = (*rgb, 1); nt = _clear(m)
    o = nt.nodes.new('ShaderNodeOutputMaterial'); b = nt.nodes.new('ShaderNodeBsdfPrincipled')
    b.inputs['Base Color'].default_value = (*rgb, 1); b.inputs['Roughness'].default_value = rough
    nt.links.new(b.outputs[0], o.inputs[0]); return m
def emis(name, rgb, strength=1.0):
    m = bpy.data.materials.new(name); nt = _clear(m)
    o = nt.nodes.new('ShaderNodeOutputMaterial'); e = nt.nodes.new('ShaderNodeEmission')
    e.inputs[0].default_value = (*rgb, 1); e.inputs[1].default_value = strength
    nt.links.new(e.outputs[0], o.inputs[0]); return m
def img_mat(name, path):
    """Unlit image (satellite ground etc.). Unlit = no darkening at grazing angles."""
    m = bpy.data.materials.new(name); nt = _clear(m)
    o = nt.nodes.new('ShaderNodeOutputMaterial'); e = nt.nodes.new('ShaderNodeEmission')
    t = nt.nodes.new('ShaderNodeTexImage'); t.image = bpy.data.images.load(path); t.interpolation = 'Cubic'
    nt.links.new(t.outputs[0], e.inputs[0]); nt.links.new(e.outputs[0], o.inputs[0]); return m
def fog_mat(name, rgb, near=80.0, far=1800.0, unlit=False):
    """Colour that fades into FOG with camera distance. unlit=True for ground/roads (no flicker)."""
    m = bpy.data.materials.new(name); nt = _clear(m)
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    if unlit: bs = nt.nodes.new('ShaderNodeEmission'); bs.inputs[0].default_value = (*rgb, 1)
    else:
        bs = nt.nodes.new('ShaderNodeBsdfPrincipled'); bs.inputs['Base Color'].default_value = (*rgb, 1); bs.inputs['Roughness'].default_value = 0.9
    cd = nt.nodes.new('ShaderNodeCameraData'); mr = nt.nodes.new('ShaderNodeMapRange')
    mr.inputs['From Min'].default_value = near; mr.inputs['From Max'].default_value = far; mr.clamp = True
    em = nt.nodes.new('ShaderNodeEmission'); em.inputs[0].default_value = (*FOG, 1); mx = nt.nodes.new('ShaderNodeMixShader')
    L = nt.links.new
    L(cd.outputs['View Distance'], mr.inputs['Value']); L(mr.outputs[0], mx.inputs[0])
    L(bs.outputs[0], mx.inputs[1]); L(em.outputs[0], mx.inputs[2]); L(mx.outputs[0], out.inputs[0]); return m

# ---------------- geometry ----------------
def link(o): sc.collection.objects.link(o); return o
def new_obj(name, bm, m, smooth=False):
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free(); me.materials.append(m)
    if smooth:
        for p in me.polygons: p.use_smooth = True
    return link(bpy.data.objects.new(name, me))
def box(name, size, loc, m, parent=None):
    bm = bmesh.new(); bmesh.ops.create_cube(bm, size=1)
    for v in bm.verts: v.co = Vector((v.co.x * size[0], v.co.y * size[1], v.co.z * size[2]))
    o = new_obj(name, bm, m); o.location = loc
    if parent: o.parent = parent
    return o
def cyl(name, r1, r2, h, loc, m, seg=32, rot=None, parent=None):
    bm = bmesh.new(); bmesh.ops.create_cone(bm, cap_ends=True, segments=seg, radius1=r1, radius2=r2, depth=h)
    o = new_obj(name, bm, m); o.location = loc
    if rot: o.rotation_euler = rot
    if parent: o.parent = parent
    return o
def empty(name, loc=(0, 0, 0), parent=None):
    e = link(bpy.data.objects.new(name, None)); e.location = loc; e.empty_display_size = 0.1
    if parent: e.parent = parent
    return e
def ground(size=30000, rgb=(0.42, 0.42, 0.43)):
    bm = bmesh.new(); bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=size)
    return new_obj('GROUND', bm, fog_mat('ground', rgb, 60, 2500, unlit=True))
def text3d(name, body, loc, size, m, rot=(math.radians(90), 0, 0), extrude=0.02, font=None):
    """Readable inscription. On a facade facing -Y use rot=(90°,0,0); facing +Y use (90°,0,pi).
    ALWAYS check with a still that it is not mirrored."""
    cu = bpy.data.curves.new(name, 'FONT'); cu.body = body; cu.size = size; cu.extrude = extrude
    cu.align_x = 'CENTER'; cu.align_y = 'CENTER'
    if font: cu.font = bpy.data.fonts.load(font)
    o = link(bpy.data.objects.new(name, cu)); o.location = loc; o.rotation_euler = rot; o.data.materials.append(m); return o
def boolean(target, cutter, op='DIFFERENCE'):
    md = target.modifiers.new('b', 'BOOLEAN'); md.operation = op; md.object = cutter; md.solver = 'EXACT'
    bpy.context.view_layer.objects.active = target
    bpy.ops.object.modifier_apply(modifier=md.name); bpy.data.objects.remove(cutter, do_unlink=True)

# ---------------- hero: box mannequin (≈1.8 m), faces -Y ----------------
def build_hero(name, body_m, head_m, eye_m, cape_m=None, cape_len=1.2):
    """Root (quaternion) -> pelvis -> torso/neck/head, shoulders->arms, hips->legs, optional cape pivot.
    Head = box with two black eyes so Seedance reads where he looks."""
    root = empty(name + '_ROOT'); root.rotation_mode = 'QUATERNION'
    pelvis = empty(name + '_PELVIS', (0, 0, 0.88), root); pelvis.rotation_mode = 'XYZ'
    box(name + '_torso', (0.52, 0.32, 0.62), (0, 0, 0.3), body_m, pelvis)
    neck = empty(name + '_NECK', (0, 0, 0.62), pelvis); neck.rotation_mode = 'XYZ'
    head = box(name + '_head', (0.32, 0.32, 0.32), (0, 0, 0.18), head_m, neck)
    for s in (-1, 1): box(name + f'_eye{s}', (0.06, 0.02, 0.06), (s * 0.075, -0.165, 0.03), eye_m, head)
    arms, legs = {}, {}
    for side, s in (('L', 1), ('R', -1)):
        sh = empty(f'{name}_SH_{side}', (s * 0.32, 0, 0.53), pelvis); sh.rotation_mode = 'XYZ'
        box(f'{name}_arm_{side}', (0.13, 0.13, 0.66), (0, 0, -0.33), body_m, sh)
        box(f'{name}_hand_{side}', (0.1, 0.12, 0.1), (0, 0, -0.7), body_m, sh); arms[side] = sh
        hp = empty(f'{name}_HIP_{side}', (s * 0.12, 0, 0.0), pelvis); hp.rotation_mode = 'XYZ'
        box(f'{name}_leg_{side}', (0.18, 0.2, 0.88), (0, 0, -0.44), body_m, hp)
        box(f'{name}_foot_{side}', (0.18, 0.3, 0.08), (0, -0.06, -0.86), body_m, hp); legs[side] = hp
    h = dict(root=root, pelvis=pelvis, neck=neck, head=head, arms=arms, legs=legs, cape=None)
    if cape_m:
        cp = empty(name + '_CAPE_PIV', (0, 0.17, 0.58), pelvis); cp.rotation_mode = 'XYZ'
        box(name + '_cape', (0.95, 0.025, cape_len), (0, 0.02, -cape_len / 2), cape_m, cp); h['cape'] = cp
    return h
def K(o, f, path): o.keyframe_insert(path, frame=f)
def kroot(h, f, loc, q): h['root'].location = loc; h['root'].rotation_quaternion = q; K(h['root'], f, 'location'); K(h['root'], f, 'rotation_quaternion')
def karm(h, side, f, rx=0.0, ry=0.0, rz=0.0): a = h['arms'][side]; a.rotation_euler = tuple(math.radians(v) for v in (rx, ry, rz)); K(a, f, 'rotation_euler')
def kleg(h, side, f, rx=0.0, rz=0.0): l = h['legs'][side]; l.rotation_euler = (math.radians(rx), 0, math.radians(rz)); K(l, f, 'rotation_euler')
def khead(h, f, yaw=0.0, pitch=0.0): n = h['neck']; n.rotation_euler = (math.radians(pitch), 0, math.radians(yaw)); K(n, f, 'rotation_euler')
def kpelvis(h, f, pitch=0.0, z=0.88, y=0.0): p = h['pelvis']; p.rotation_euler = (math.radians(pitch), 0, 0); p.location = (0, y, z); K(p, f, 'rotation_euler'); K(p, f, 'location')
def kcape(h, f, rx, sx=1.0): c = h['cape']; c.rotation_euler = (math.radians(rx), 0, 0); c.scale = (sx, 1, 1); K(c, f, 'rotation_euler'); K(c, f, 'scale')
def face_q(direction): return Vector(direction).normalized().to_track_quat('-Y', 'Z')   # hero looks along direction
def walk(h, f0, f1, p0, p1, step=22, swing=18):
    """Linear walk with leg swing, keys every 2 frames."""
    q = face_q(Vector(p1) - Vector(p0))
    for f in range(f0, f1 + 1, 2):
        u = (f - f0) / max(1, f1 - f0); kroot(h, f, Vector(p0).lerp(Vector(p1), u), q)
        ph = math.sin(2 * math.pi * f / step); kleg(h, 'L', f, swing * ph); kleg(h, 'R', f, -swing * ph)
def crouch(h, f):
    kpelvis(h, f, 40, 0.5, 0.35); kleg(h, 'L', f, -90, 12); kleg(h, 'R', f, -88, -12)
def hide_range(prefix, f_on, f_off=None):
    """Visible only in [f_on, f_off). CONSTANT interpolation is applied by finish()."""
    for o in [o for o in bpy.data.objects if o.name.startswith(prefix)]:
        if f_on > 0: o.hide_render = True; K(o, f_on - 1, 'hide_render')
        o.hide_render = False; K(o, f_on, 'hide_render')
        if f_off is not None: o.hide_render = True; K(o, f_off, 'hide_render')
def hero_axes(h, f):
    """World FWD/RIGHT/HEAD of a hero at frame f (call after keys exist)."""
    sc.frame_set(f); bpy.context.view_layer.update(); M = h['root'].matrix_world.copy()
    fwd = (M.to_3x3() @ Vector((0, -1, 0))).normalized(); right = fwd.cross(UP).normalized()
    return dict(M=M, FWD=fwd, RIGHT=right, HEAD=M @ Vector((0, 0, 1.70)), CHEST=M @ Vector((0, 0, 1.3)))

# ---------------- cameras ----------------
_prev = {}
def cam(name, lens=35, clip_start=0.02):
    cd = bpy.data.cameras.new(name); cd.lens = lens; cd.sensor_fit = 'AUTO'; cd.sensor_width = 36
    cd.clip_start = clip_start; cd.clip_end = 40000
    o = link(bpy.data.objects.new(name, cd)); o.rotation_mode = 'XYZ'; return o
def look(o, pos, tgt, max_down=45):
    d = Vector(tgt) - Vector(pos); hz = math.hypot(d.x, d.y)
    if hz > 1e-6 and math.atan2(-d.z, hz) > math.radians(max_down): d.z = -hz * math.tan(math.radians(max_down))
    o.location = pos; q = d.to_track_quat('-Z', 'Y')
    e = q.to_euler('XYZ', _prev[o.name]) if o.name in _prev else q.to_euler('XYZ')   # euler continuity: no 360° flips
    _prev[o.name] = e.copy(); o.rotation_euler = e
def ckey(o, f, pos, tgt, lens=None):
    """Key camera position+aim (+lens). Key EVERY frame for moves: smooth and predictable."""
    look(o, pos, tgt); K(o, f, 'location'); K(o, f, 'rotation_euler')
    if lens: o.data.lens = lens; o.data.keyframe_insert('lens', frame=f)
def ease(u): u = max(0.0, min(1.0, u)); return (1 - math.cos(math.pi * u)) / 2
def ease_out(u): u = max(0.0, min(1.0, u)); return 1 - (1 - u) ** 3
def ease_in(u): u = max(0.0, min(1.0, u)); return u ** 3
def orbit_pos(center, fwd, right, phi, r, dz=0.0):
    """phi=0 in front of the hero (on FWD), +90° on his right, 180° behind."""
    return Vector(center) + (fwd * math.cos(phi) + right * math.sin(phi)) * r + UP * dz
def handheld(t, amp_pos=0.008, amp_aim=0.3):
    """Gentle handheld float (pos offset, aim offset). Bigger values look jittery."""
    fl = Vector((amp_pos * math.sin(2 * math.pi * 0.35 * t), amp_pos * 0.9 * math.sin(2 * math.pi * 0.47 * t + 1), amp_pos * 0.75 * math.sin(2 * math.pi * 0.55 * t + 2)))
    aj = Vector((amp_aim * math.sin(2 * math.pi * 0.4 * t + .5), amp_aim * 0.85 * math.sin(2 * math.pi * 0.31 * t + 1.7), amp_aim * 0.7 * math.sin(2 * math.pi * 0.52 * t)))
    return fl, aj
def lens_cover(camera, m, name='LENS_COVER'):
    """Black plane parented to the camera: use for 'coat/hood covers the lens' transitions
    (real geometry closer than clip_start is not rendered)."""
    p = box(name, (0.2, 0.2, 0.001), (0, 0, -0.06), m); p.parent = camera; p.matrix_parent_inverse.identity(); return p
def markers(cuts):
    """cuts = [(frame, camera_obj), ...] -> hard cuts via timeline markers."""
    sc.timeline_markers.clear()
    for f, c in cuts: sc.timeline_markers.new(c.name, frame=f).camera = c
    sc.camera = cuts[0][1]

# ---------------- animation utils ----------------
def fcurves(idb):
    ad = getattr(idb, 'animation_data', None)
    if not ad or not ad.action: return []
    try: return [fc for l in ad.action.layers for st in l.strips for cb in st.channelbags for fc in cb.fcurves]
    except Exception: return list(ad.action.fcurves)
def action_fcurves(act):
    try: return [fc for l in act.layers for st in l.strips for cb in st.channelbags for fc in cb.fcurves]
    except Exception: return list(act.fcurves)
def retime(remap, skip_actions=()):
    """Shift/scale ALL keys: remap(frame)->new frame. Each bpy.data.action exactly once
    (Blender 5 slotted actions: object and its camera data can share one action)."""
    for act in bpy.data.actions:
        if act.name in skip_actions: continue
        for fc in action_fcurves(act):
            for kp in fc.keyframe_points:
                x = kp.co.x; dx = remap(x) - x; kp.co.x += dx; kp.handle_left.x += dx; kp.handle_right.x += dx
            fc.update()
def clear_keys_after(o, path, f0):
    for fc in [fc for fc in fcurves(o) if fc.data_path == path]:
        for i in reversed(range(len(fc.keyframe_points))):     # reversed index: avoids 'Keyframe not in F-Curve'
            if fc.keyframe_points[i].co.x >= f0: fc.keyframe_points.remove(fc.keyframe_points[i])
def finish(linear_cams=()):
    """hide_render -> CONSTANT; listed cameras -> LINEAR (they are keyed every frame)."""
    for o in bpy.data.objects:
        for fc in fcurves(o):
            for kp in fc.keyframe_points:
                if fc.data_path == 'hide_render': kp.interpolation = 'CONSTANT'
    for o in linear_cams:
        for fc in fcurves(o) + fcurves(o.data):
            for kp in fc.keyframe_points: kp.interpolation = 'LINEAR'

# ---------------- output ----------------
def out_dir(default='previz_out'):
    """Output folder: `-- out DIR` on the command line, else ./previz_out (relative to the current folder)."""
    import os
    d = ARGS[ARGS.index('out') + 1] if 'out' in ARGS else os.path.join(os.getcwd(), default)
    os.makedirs(os.path.join(d, 'renders'), exist_ok=True); return os.path.abspath(d)

def save_and_run(blend_path, raw_prefix, still_prefix):
    """CLI: -- render | -- stills 10,50,120   (combine with: out DIR)"""
    light_mode()
    bpy.ops.wm.save_as_mainfile(filepath=blend_path); print('BUILD OK')
    if 'render' in ARGS:
        r = sc.render; r.image_settings.media_type = 'VIDEO'; r.image_settings.file_format = 'FFMPEG'
        r.ffmpeg.format = 'MPEG4'; r.ffmpeg.codec = 'H264'; r.ffmpeg.constant_rate_factor = 'HIGH'; r.ffmpeg.audio_codec = 'NONE'
        r.filepath = raw_prefix; bpy.ops.render.render(animation=True); print('RENDER OK')
    elif 'stills' in ARGS:
        sc.render.image_settings.media_type = 'IMAGE'; sc.render.image_settings.file_format = 'PNG'
        for f in [int(x) for x in ARGS[ARGS.index('stills') + 1].split(',')]:
            sc.frame_set(f); sc.render.filepath = f'{still_prefix}{f:04d}.png'; bpy.ops.render.render(write_still=True)
