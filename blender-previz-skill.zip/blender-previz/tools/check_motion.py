"""Camera smoothness report. Run: Blender -b file.blend -P check_motion.py -- 0 575
Prints per-frame translation / rotation speed of the ACTIVE camera (markers respected) and flags jumps
(>3x median, excluding marker cuts)."""
import bpy, sys, math, statistics
a = sys.argv[sys.argv.index('--') + 1:]; f0, f1 = int(a[0]), int(a[1])
sc = bpy.context.scene; cuts = {m.frame for m in sc.timeline_markers}
prev = None; rows = []
for f in range(f0, f1 + 1):
    sc.frame_set(f); c = sc.camera; M = c.matrix_world.copy()
    if prev and prev[0] == c.name and f not in cuts:
        dt = (M.translation - prev[1].translation).length
        dr = math.degrees(M.to_quaternion().rotation_difference(prev[1].to_quaternion()).angle)
        rows.append((f, c.name, dt, dr))
    prev = (c.name, M)
mt = statistics.median([r[2] for r in rows] or [0]) or 1e-6; mr = statistics.median([r[3] for r in rows] or [0]) or 1e-6
for i in range(1, len(rows)):
    f, n, dt, dr = rows[i]; pdt, pdr = rows[i - 1][2], rows[i - 1][3]
    if (dt > 3 * max(mt, pdt) and dt > 0.02) or (dr > 3 * max(mr, pdr) and dr > 0.3):
        print(f'JUMP f{f} {n}: move {dt:.3f} m (prev {pdt:.3f}), rot {dr:.2f}° (prev {pdr:.2f})')
print('cuts at', sorted(cuts), '| median move %.3f m/f, rot %.2f°/f' % (mt, mr), '| CHECK DONE')
