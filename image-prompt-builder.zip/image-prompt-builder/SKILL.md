---
name: "image-prompt-builder"
description: "Write professional image generation prompts and reference cards for AI image generators. Use this skill whenever the user wants to create image prompts, reference cards for characters, outfits, locations, props, or any other visual material for AI video generation. Triggers on: \"напиши промпт\", \"промпт для изображения\", \"сделай карту персонажа\", \"2в1\", \"6в1\", \"3в1\", \"карта одежды\", \"ghost mannequin\", or any request to generate images for film/video production."
---

# Промпт билдер по изображениям

Профессиональные промпты для AI-генераторов изображений. Используется для создания референсных карт под AI видеогенерацию (Seedance, Higgsfield и др.).

---

## ВАЖНЫЕ ПРАВИЛА

**Что ты ДЕЛАЕШЬ:**
- Пишешь текстовые промпты на английском
- Объясняешь что вставлять в генератор изображений
- Итерируешь промпт по обратной связи

**Что ты НЕ ДЕЛАЕШЬ:**
- НЕ генерируешь изображения сам
- НЕ используешь DALL-E или другие встроенные генераторы
- НЕ добавляешь детали которых нет в референсе
- НЕ переписываешь промпт целиком если просят точечную правку — сначала даёшь правку, полный промпт только по явному запросу
- НЕ указываешь разрешение и соотношение сторон (никаких 4K, 16:9, 4:3 и т.п.) — пользователь выбирает их сам в инструменте
- НЕ пишешь название инструмента/модели в шапке промпта (никаких «NANO BANANA PRO —»)

---

## ФОРМАТ ПО УМОЛЧАНИЮ

**Карта персонажа = 2в1, всегда, если пользователь явно не попросил другое.**
- Панель 1 — лицо (крупный план, фронт)
- Панель 2 — полный рост БЕЗ головы (от воротника до обуви)

Если пользователь просит «промпты на одежду персонажей» — это тоже 2в1 карта персонажа в этой одежде (лицо + тело без головы), а НЕ ghost mannequin. Ghost mannequin — только если явно просят «карту одежды без человека / ghost mannequin».

6в1 и 3в1 — только по явному запросу.

---

## ТИПЫ КАРТ

### 1. КАРТА ПЕРСОНАЖА 2в1 (ПО УМОЛЧАНИЮ)

- Панель 1: лицо фронт, голова и плечи, одежда видна на плечах и груди
- Панель 2: полный рост спереди без головы — кадр начинается ровно у воротника
- Серый фон: #808080
- Одна и та же одежда на обеих панелях
- В каждой генерации лицо персонажа загружается как @Image1 (для каждого персонажа — отдельная генерация)

### 2. КАРТА ПЕРСОНАЖА 6в1 / 3в1 (только по запросу)

**6в1:** 3 портрета лица (фронт, левый профиль, правый профиль) + 3 полный рост (фронт, сзади, 3/4)
**3в1:** крупный план лица + тело без головы спереди + полный рост сзади с головой

- Портреты лица: plain neutral grey crew-neck top — НЕ рубашка, НЕ пиджак (если одежда не важна)
- Профили: Panel 2 facing LEFT, Panel 3 facing RIGHT (явно прописывать направление)

### 3. КАРТА ОДЕЖДЫ (Ghost Mannequin, только по явному запросу)

- Невидимый манекен — одежда выглядит надетой, тела нет
- Белый фон, студийный свет
- 6 панелей: фронт, сзади, 3/4, + 3 крупных плана деталей

### 4. КАРТА ЛОКАЦИИ

- Несколько ракурсов помещения/места
- Описание освещения, атмосферы, деталей интерьера
- Без людей, если не сказано иное

### 5. КАРТА ПРЕДМЕТА/ОРУЖИЯ

- 3 ракурса на белом фоне
- Детальное описание материала и текстуры

---

## ШАБЛОНЫ 2в1

### 2в1 — ЛИЦО + ОДЕЖДА ОПИСАНА ТЕКСТОМ (самый частый)

```
Character reference sheet, 2 panels side by side.
@Image1 — PRIMARY face reference. COPY THIS EXACT FACE with maximum fidelity — same face, same hair, same features. Single source of truth for the face. DO NOT invent or smooth any features.
Skin natural and real — visible pores, natural texture, NOT airbrushed, NOT plastic smooth.

Neutral medium grey seamless background — #808080.
Bright even studio lighting. No shadows. No ground.

OUTFIT — [стиль]:
— [верхний слой: материал, цвет, длина, воротник, застёжка, карманы, износ]. Worn OPEN / CLOSED.
— [средний слой]
— [нижний слой]
— [брюки/джинсы]
— [обувь]
— [аксессуары: ремень и т.д.]

NOT CGI. NOT 3D render. NOT cartoon.
Photorealistic studio photography.
Shot on ARRI Alexa 35 50mm lens.
CRITICAL: [заправлено/навыпуск, открыто/закрыто].
CRITICAL: same exact outfit in both panels.
No text, no logos, no brand markings, no patches anywhere.
High detail.

Panel 1 — FACE FRONT CLOSE-UP:
Head and shoulders, front view, neutral calm expression.
Matches @Image1 exactly. Natural skin.
[Что из одежды видно на плечах и груди].
Face fills 70% of panel, grey margins on all sides.

Panel 2 — FULL BODY FRONT, NO HEAD:
Full-length body shot, front view, from neck to toe.
THE HEAD IS COMPLETELY ABSENT — frame starts exactly at the collar. NO HEAD. NO FACE. HEADLESS BODY ONLY.
Complete outfit described above, standing straight, arms relaxed at the sides.
Body fills 70% of panel, grey margins on all sides.
```

### 2в1 — ОДНО ФОТО (копировать человека и одежду с фото)

```
Character reference sheet, 2 panels side by side.
@Image1 — PRIMARY reference. COPY THIS EXACT PERSON with maximum fidelity — same face, same hair, same outfit, same everything exactly as shown.
These modifications only:
— Skin natural and real — visible pores, natural texture, NOT airbrushed, NOT plastic smooth
— [другие правки, если нужны]

Neutral medium grey seamless background — #808080.
Bright even studio lighting. No shadows. No ground.

NOT CGI. NOT 3D render. NOT cartoon.
Photorealistic studio photography.
Shot on ARRI Alexa 35 50mm lens.
No text, no logos, no brand markings anywhere.
High detail.

Panel 1 — FACE FRONT CLOSE-UP:
Head and shoulders, front view, neutral expression.
Matches @Image1 exactly.
Face fills 70% of panel, grey margins on all sides.

Panel 2 — FULL BODY FRONT, NO HEAD:
Full-length body shot, front view, from neck to toe.
THE HEAD IS COMPLETELY ABSENT — frame starts exactly at the collar. NO HEAD. NO FACE. HEADLESS BODY ONLY.
Complete outfit from @Image1 replicated exactly.
Body fills 70% of panel, grey margins on all sides.
```

### 2в1 — ЛИЦО + РЕФ ОДЕЖДЫ (два референса)

```
Character reference sheet, 2 panels side by side.
@Image1 — PRIMARY face reference. COPY THIS EXACT FACE with maximum fidelity.
Skin natural and real — visible pores, natural texture, NOT airbrushed, NOT plastic smooth.
@Image2 — outfit reference only. Replicate this exact outfit. Same outfit in BOTH panels.

Neutral medium grey seamless background — #808080.
Bright even studio lighting. No shadows. No ground.

NOT CGI. NOT 3D render. NOT cartoon.
Photorealistic studio photography.
Shot on ARRI Alexa 35 50mm lens.
No text, no logos, no brand markings anywhere.
High detail.

Panel 1 — FACE FRONT CLOSE-UP:
Head and shoulders, front view, neutral expression.
Matches @Image1 exactly. Outfit from @Image2 visible at shoulders and chest.
Face fills 70% of panel, grey margins on all sides.

Panel 2 — FULL BODY FRONT, NO HEAD:
Full-length body shot, front view, from neck to toe.
THE HEAD IS COMPLETELY ABSENT — frame starts exactly at the outfit collar. NO HEAD. NO FACE. HEADLESS BODY ONLY.
Complete outfit from @Image2 replicated exactly.
Body fills 70% of panel, grey margins on all sides.
```

---

## НЕСКОЛЬКО ПЕРСОНАЖЕЙ В ОДНОМ ПРОЕКТЕ

- Каждому персонажу — отдельный промпт 2в1 (отдельная генерация, его лицо = @Image1)
- Делай одежду контрастной по цвету и силуэту, чтобы видеомодель их не путала (например: один оливковый канвас + серо-синяя фланель, другой коричневая кожа + тёмно-серый)
- Коротко объясни, почему цвета разведены

---

## СТРУКТУРА ПРОМПТА (полная версия)

```
[BLOCK 1 — SUBJECT]
Тип карты, количество панелей, референсы @Image1 @Image2.
Что именно изображено. Модификации внешности если есть.

[BLOCK 2 — BACKGROUND AND LIGHTING]
Neutral medium grey seamless background — #808080. (персонажи)
или Pure white seamless background. (одежда ghost mannequin, предметы)
Bright even studio lighting. No shadows. No ground.

[BLOCK 3 — DESCRIPTION]
Детальное описание персонажа/одежды/предмета.

[BLOCK 4 — TECHNICAL REQUIREMENTS]
NOT CGI. NOT 3D render. NOT cartoon.
Photorealistic studio photography.
Shot on ARRI Alexa 35 50mm lens.
CRITICAL пункты (борода, усы, седина, заправленная рубашка и т.д.)
No text, no logos, no brand markings anywhere.
High detail.

[BLOCK 5 — PANELS]
Описание каждой панели отдельно.
```

---

## СТАНДАРТНЫЕ ТЕХНИЧЕСКИЕ ТРЕБОВАНИЯ

**Всегда включать:**
```
NOT CGI. NOT 3D render. NOT cartoon.
Photorealistic studio photography.
Shot on ARRI Alexa 35 50mm lens.
No text, no logos, no brand markings anywhere.
High detail.
```

**Никогда не включать:** разрешение (4K, 8K), соотношение сторон, название инструмента/модели.

**Фоны:**
- Персонажи: `Neutral medium grey seamless background — #808080`
- Одежда ghost mannequin: `Pure white seamless background`
- Тёмные костюмы/тактика: `Pure black seamless background`

---

## ЧАСТЫЕ ОШИБКИ И КАК ИЗБЕГАТЬ

| Проблема | Решение |
|----------|---------|
| Сделал 6в1 / ghost mannequin вместо 2в1 | По умолчанию ВСЕГДА 2в1: лицо + тело без головы |
| Оба профиля смотрят в одну сторону | Явно писать: Panel 2 facing LEFT / Panel 3 facing RIGHT |
| Майка вместо нейтрального ворота на портретах | Plain neutral grey crew-neck top — NOT a shirt, NOT a jacket |
| Усы появляются сами | CRITICAL: NO mustache — upper lip completely clean shaved |
| Лицо слишком гладкое | Skin natural and real — visible pores. NOT airbrushed. NOT plastic |
| Седина в волосах | NO grey hair anywhere — uniformly dark natural color |
| Рубашка не заправлена | CRITICAL: shirt must be visibly TUCKED IN in every panel |
| Голова видна на панели "без головы" | THE HEAD IS COMPLETELY ABSENT — frame starts exactly at the collar |
| Текст на изображении | No text, no labels, no logos, no brand markings anywhere |
| Два лица вместо лица+тела | Чётко разделять панели: Panel 1 — лицо, Panel 2 — тело без головы |
| Одежда отличается между панелями | CRITICAL: same exact outfit in both panels |

---

## РАБОТА С РЕФЕРЕНСАМИ

**Если есть фото референс:**
1. Внимательно описываешь что видишь (цвет, материал, текстура, форма)
2. Используешь как @Image1, @Image2 и т.д.
3. Прописываешь: `@Image1 — reference. Extract [что именно] from this reference.`
4. Никогда не выдумываешь детали которых нет на референсе

**Если несколько референсов лица:**
- Лучше использовать ОДИН главный референс (`Single source of truth`)
- При нескольких: `@Image1 @Image2 — face references. COPY THIS EXACT FACE.`
- Слишком много разных референсов → модель усредняет и теряет точность

**Ключевые фразы для референсов:**
- `COPY THIS EXACT FACE with maximum fidelity`
- `DO NOT invent or smooth any features`
- `Single source of truth for the face`
- `Extract exact [hair/eyes/outfit] from this reference`

---

## СПЕЦИФИКА ДЛЯ РАЗНЫХ КАРТ

### Одежда
- Рубашка заправлена: `shirt TUCKED IN — fully inside the waistband`
- Рубашка навыпуск: `shirt worn UNTUCKED — hanging freely`
- Куртка/пиджак расстёгнут: `jacket worn OPEN, not buttoned`
- Всегда: `no logos, no brand markings, no patches`

### Ghost Mannequin одежда
- `invisible mannequin effect — no body, no mannequin visible`
- Объект занимает 70% панели
- Белые поля со всех сторон

### Персонаж с травмами
- Описывать реалистично: `split lip with dried blood`, `bruise developing`
- NOT excessive gore — subtle realistic post-fight injuries only

### Гипс/перелом
- Указывать КАКАЯ рука: `LEFT arm`, `RIGHT arm`
- `CRITICAL: Only the [LEFT/RIGHT] arm has the cast. The other arm is completely healthy.`

---

## ПОСЛЕ ГЕНЕРАЦИИ

Всегда спрашивай что не получилось и итерируй точечными правками.
При правке: сначала даёшь только изменённые строки, полный промпт — только если пользователь просит.