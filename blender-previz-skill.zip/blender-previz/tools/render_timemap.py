"""Render a previz .blend at fractional frame times from timemap.json (true in-betweens for slow-mo; black where the edit is black).
Blender -b PREVIZ.blend -P render_timemap.py -- /path/to/dir_with_timemap
Then: ffmpeg -framerate 24 -i DIR/pv/%04d.png ... (all frames incl. black are written)."""
import bpy, json, math, sys, os
D = sys.argv[sys.argv.index('--') + 1]; os.makedirs(D + '/pv', exist_ok=True)
m = json.load(open(D + '/timemap.json')); black = set(m['black']); sc = bpy.context.scene
sc.render.image_settings.media_type = 'IMAGE'; sc.render.image_settings.file_format = 'PNG'
for i, t in enumerate(m['t']):
    if i in black: continue
    t = min(max(t, sc.frame_start), sc.frame_end); f = int(math.floor(t))
    sc.frame_set(f, subframe=t - f); sc.render.filepath = D + f'/pv/{i:04d}.png'; bpy.ops.render.render(write_still=True)
img = bpy.data.images.new('black', sc.render.resolution_x, sc.render.resolution_y)
img.pixels = [0.0, 0.0, 0.0, 1.0] * (sc.render.resolution_x * sc.render.resolution_y)
for i in black: img.filepath_raw = D + f'/pv/{i:04d}.png'; img.file_format = 'PNG'; img.save()
print('TIMEMAP RENDER OK')
