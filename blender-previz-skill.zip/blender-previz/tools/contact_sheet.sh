#!/bin/zsh
# contact_sheet.sh video.mp4 out.jpg [every_sec=1] [cols=6]
ffmpeg -v error -y -i "$1" -vf "fps=1/${3:-1},scale=320:-1,tile=${4:-6}x5" -frames:v 1 "$2" && echo "$2"
# luma per frame (black/flash check):
# ffmpeg -i video.mp4 -vf signalstats,metadata=print:key=lavfi.signalstats.YAVG -f null - 2>&1 | grep YAVG
